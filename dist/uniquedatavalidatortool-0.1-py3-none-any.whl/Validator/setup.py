from setuptools import setup, find_packages
setup(
    name='datavalidator',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='Khadijat Agboola',
    author_email='khadijahagboola12@gmail.com',
    description='A simple data validation package'
)